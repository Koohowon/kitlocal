import React from "react";
import { NavLink } from 'react-router-dom';
import { useState, useEffect } from "react";
import twoverse from '../../img/logo.png';
import './SideOpenbar.css';

export default function SideOpenbar({ children }) {

    const copyToClipboard = (text) => {
        const textarea = document.createElement('textarea');
        textarea.value = text;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
    };

    const pasteCheckCode = async () => {
        try {
            const response = await fetch("http://localhost:3001/user/findCheckCode");
            const data = await response.json();
            copyToClipboard(data.checkCode);
            alert("인증키가 복사되었습니다");
            // alert(checkCode);
        } catch (error) {
            console.error('사용자 데이터 및 체크 코드를 가져오는 중 오류 발생:', error);
        }
    }

    return (
        <div className="barContainer">
            <div className="sideOpenbar">
                <div className="top_section">
                    <div className="logo"><img src={twoverse} /></div>

                </div>
                <hr />
                <div className="menus">
                    <NavLink className="link"
                        activeclassName="active"
                        to="/">
                        <div className="link_text">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-clipboard-data" viewBox="0 0 16 16">
                                <path d="M4 11a1 1 0 1 1 2 0v1a1 1 0 1 1-2 0v-1zm6-4a1 1 0 1 1 2 0v5a1 1 0 1 1-2 0V7zM7 9a1 1 0 0 1 2 0v3a1 1 0 1 1-2 0V9z" />
                                <path d="M4 1.5H3a2 2 0 0 0-2 2V14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V3.5a2 2 0 0 0-2-2h-1v1h1a1 1 0 0 1 1 1V14a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V3.5a1 1 0 0 1 1-1h1v-1z" />
                                <path d="M9.5 1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5v-1a.5.5 0 0 1 .5-.5h3zm-3-1A1.5 1.5 0 0 0 5 1.5v1A1.5 1.5 0 0 0 6.5 4h3A1.5 1.5 0 0 0 11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3z" />
                            </svg>
                            대시보드 </div>
                    </NavLink>
                    <NavLink className="link"
                        activeclassName="active"
                        to="/Main">
                        <div className="link_text">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-mortarboard" viewBox="0 0 16 16">
                                <path d="M8.211 2.047a.5.5 0 0 0-.422 0l-7.5 3.5a.5.5 0 0 0 .025.917l7.5 3a.5.5 0 0 0 .372 0L14 7.14V13a1 1 0 0 0-1 1v2h3v-2a1 1 0 0 0-1-1V6.739l.686-.275a.5.5 0 0 0 .025-.917l-7.5-3.5ZM8 8.46 1.758 5.965 8 3.052l6.242 2.913L8 8.46Z" />
                                <path d="M4.176 9.032a.5.5 0 0 0-.656.327l-.5 1.7a.5.5 0 0 0 .294.605l4.5 1.8a.5.5 0 0 0 .372 0l4.5-1.8a.5.5 0 0 0 .294-.605l-.5-1.7a.5.5 0 0 0-.656-.327L8 10.466 4.176 9.032Zm-.068 1.873.22-.748 3.496 1.311a.5.5 0 0 0 .352 0l3.496-1.311.22.748L8 12.46l-3.892-1.556Z" />
                            </svg>
                            공정평가
                        </div>
                    </NavLink>
                </div>
                <hr />
                <div className="bottom"
                onClick={pasteCheckCode}>
                    인증키 클릭
                </div>
            </div>
            <main>{children}</main>
        </div>
    )
}